# Chatting-Between-Peers
A simple chat program between two devices on the same network<br>
## part One<br>
1- Run the file as a java project<br>
2-In the Username field, put your name<br>
3-In the Local IP field, put the IP of your device<br>
4-In the Local Port field, put the port that you will send through<br>
5-In the Remote IP field, put the IP of the other device<br>
6-In the Remote Port field, put any port chosen by the other device<br>
7-Click on the test button<br>
8-Repeat the steps on the other device<br>
9-Write a message on one of the two devices and send it<br><br>
ّ
🔴No need to fill in the rest of the fields<br>
ّّّ
![image](https://user-images.githubusercontent.com/93814390/208264151-e66bcb33-5f44-42f9-b218-c0e94d78df91.png)
## The second part
1- Run the TCP file and make sure the port is filled and start listening<br>
![image](https://user-images.githubusercontent.com/93814390/208264265-d419bec6-6901-4a43-8a0e-4bc61bf253b8.png)<br>
2-Run the client class<br>
3-Log in according to the information in the file<br>
4-Fill in the tcp ip and port<br>
5- Fill in the fields as you did in the first part<br>
6-When you click the send to all button without specifying the port, a message will be sent to all clients<br>
7-If you specify the port and press send, it will be sent to the specified port<br>
![image](https://user-images.githubusercontent.com/93814390/208264402-3c0427e1-af78-4ed5-ab04-da69b318a175.png)

